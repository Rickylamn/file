---
layout: post
title: "A Post with a Video"
description: "Custom written post descriptions are the way to go... if you're not lazy."
category: misc
tags: books, video
---

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/2DLnhdnSUVs" frameborder="0" allowfullscreen></iframe></center><br>



```html
<center><iframe width="560" height="315" src="https://www.youtube.com/embed/2DLnhdnSUVs" frameborder="0" allowfullscreen></iframe></center>
```